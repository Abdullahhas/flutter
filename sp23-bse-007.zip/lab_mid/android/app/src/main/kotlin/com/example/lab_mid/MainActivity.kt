package com.example.lab_mid

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
